import logging
import os

import dataiku
import pandas as pd

from alm_monitoring import ModelMonitor
from alm_monitoring.config import MonitoringConfig

logging.basicConfig(level=logging.INFO)

config_path = os.path.join(
    os.environ["DIP_HOME"], "config", "projects",
    dataiku.default_project_key(), "lib", "python", "configs",
    "lending_club_prepayment.yaml",
)
monitor = ModelMonitor(MonitoringConfig.from_yaml(config_path))

reference = dataiku.Dataset("lc_reference").get_dataframe(infer_with_pandas=True)
current = dataiku.Dataset("lc_current").get_dataframe(infer_with_pandas=True)
for df in (reference, current):
    df["issue_d"] = pd.to_datetime(df["issue_d"])

frames = [r.to_dataframe() for r in monitor.run_over_time(reference, current, freq="MS")]
history = pd.concat(frames, ignore_index=True)
history["window_start"] = pd.to_datetime(history["window_start"])

dataiku.Dataset("monitoring_kpis").write_with_schema(history)
print(history.groupby("severity").size())